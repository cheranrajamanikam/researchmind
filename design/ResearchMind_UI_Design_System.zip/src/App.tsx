import { useMemo, useState } from "react";

type IconName =
  | "archive"
  | "arrow"
  | "book"
  | "check"
  | "chevron"
  | "clock"
  | "close"
  | "copy"
  | "download"
  | "file"
  | "folder"
  | "grid"
  | "help"
  | "home"
  | "list"
  | "moon"
  | "more"
  | "plus"
  | "search"
  | "settings"
  | "spark"
  | "sun"
  | "thread"
  | "upload"
  | "user"
  | "wifi";

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    archive: <><rect x="3" y="5" width="18" height="15" rx="2" /><path d="M8 10h8M5 3h14v2H5z" /></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
    book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v17H6.5A2.5 2.5 0 0 0 4 22V5.5ZM20 5.5A2.5 2.5 0 0 0 17.5 3H13v17h4.5A2.5 2.5 0 0 1 20 22V5.5Z" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    close: <path d="M6 6l12 12M18 6 6 18" />,
    copy: <><rect x="8" y="8" width="11" height="11" rx="2" /><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" /></>,
    download: <><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14" /></>,
    file: <><path d="M6 2h8l4 4v16H6z" /><path d="M14 2v5h5M9 12h6M9 16h6" /></>,
    folder: <path d="M3 6h7l2 2h9v11H3z" />,
    grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
    help: <><circle cx="12" cy="12" r="9" /><path d="M9.5 9a2.7 2.7 0 1 1 4.2 2.25c-1.1.7-1.7 1.15-1.7 2.25M12 17h.01" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    list: <><path d="M9 6h11M9 12h11M9 18h11" /><circle cx="4.5" cy="6" r=".5" /><circle cx="4.5" cy="12" r=".5" /><circle cx="4.5" cy="18" r=".5" /></>,
    moon: <path d="M20 15.5A8.5 8.5 0 0 1 8.5 4 8.5 8.5 0 1 0 20 15.5Z" />,
    more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 5 5" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
    spark: <><path d="M12 3v4M12 17v4M3 12h4M17 12h4" /><circle cx="12" cy="12" r="3" /></>,
    sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
    thread: <><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z" /><path d="M8 9h8M8 13h5" /></>,
    upload: <><path d="M12 16V4m0 0L7 9m5-5 5 5" /><path d="M4 15v5h16v-5" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    wifi: <><path d="M4 9a12 12 0 0 1 16 0M7 13a7.5 7.5 0 0 1 10 0M10 17a3 3 0 0 1 4 0" /><circle cx="12" cy="20" r=".7" /></>,
  };
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function Button({ children, icon, variant = "secondary", onClick, disabled = false }: { children?: React.ReactNode; icon?: IconName; variant?: "primary" | "secondary" | "ghost" | "danger"; onClick?: () => void; disabled?: boolean }) {
  return <button className={`button button--${variant}`} onClick={onClick} disabled={disabled}>{icon && <Icon name={icon} size={16} />}{children}</button>;
}

function IconButton({ icon, label, onClick }: { icon: IconName; label: string; onClick?: () => void }) {
  return <button className="icon-button" aria-label={label} title={label} onClick={onClick}><Icon name={icon} /></button>;
}

function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: "neutral" | "teal" | "blue" | "amber" }) {
  return <span className={`pill pill--${tone}`}>{children}</span>;
}

function Disclaimer() {
  return <span className="disclaimer" title="Generated analyses can be incomplete. Review the cited source before relying on this result."><Icon name="help" size={13} />Analytical estimate, not proof</span>;
}

function HowComputed({ label = "How this was computed" }: { label?: string }) {
  return <details className="computed"><summary>{label}<Icon name="chevron" size={14} /></summary><div className="computed__body"><div><b>Retrieval</b><span>Hybrid keyword + semantic search · top 12 passages</span></div><div><b>Analysis</b><span>qwen2.5:14b · temperature 0.1 · two independent passes</span></div><div><b>Completed</b><span>Today, 10:42 · local machine · 18.4 seconds</span></div></div></details>;
}

const papers = [
  { title: "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks", authors: "Lewis et al.", year: "2020", venue: "NeurIPS", pages: 12, tag: "Foundational", status: "Reviewed" },
  { title: "Lost in the Middle: How Language Models Use Long Contexts", authors: "Liu et al.", year: "2024", venue: "TACL", pages: 27, tag: "Benchmark", status: "To review" },
  { title: "Self-RAG: Learning to Retrieve, Generate, and Critique", authors: "Asai et al.", year: "2024", venue: "ICLR", pages: 19, tag: "Methodology", status: "Extracted" },
  { title: "Precise Zero-Shot Dense Retrieval without Relevance Labels", authors: "Gao et al.", year: "2023", venue: "ACL", pages: 18, tag: "Recent", status: "Reviewed" },
  { title: "Benchmarking Large Language Models in Retrieval-Augmented Generation", authors: "Chen et al.", year: "2024", venue: "AAAI", pages: 22, tag: "Benchmark", status: "Processing" },
];

function EvidenceCard({ compact = false, highlighted = false, onOpen }: { compact?: boolean; highlighted?: boolean; onOpen?: () => void }) {
  return <article className={`evidence-card ${compact ? "evidence-card--compact" : ""} ${highlighted ? "evidence-card--highlighted" : ""}`}>
    <div className="evidence-card__top"><Pill tone={highlighted ? "amber" : "blue"}>p. 6</Pill><span>Lewis et al. · 2020</span></div>
    <blockquote>“RAG models combine a pre-trained parametric memory with a non-parametric memory accessed through a dense vector index.”</blockquote>
    <div className="evidence-card__source"><span>Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks</span><div><IconButton icon="copy" label="Copy citation" /><Button variant="ghost" onClick={onOpen}>Open in viewer <Icon name="arrow" size={14} /></Button></div></div>
  </article>;
}

function PageTitle({ eyebrow, title, description, actions }: { eyebrow?: string; title: string; description: string; actions?: React.ReactNode }) {
  return <header className="page-title"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1>{title}</h1><p>{description}</p></div>{actions && <div className="page-title__actions">{actions}</div>}</header>;
}

function ProgressJob({ title, detail, progress, status = "running" }: { title: string; detail: string; progress: number; status?: "running" | "done" | "queued" | "failed" }) {
  return <div className="job"><div className={`job__icon job__icon--${status}`}>{status === "done" ? <Icon name="check" /> : status === "queued" ? <Icon name="clock" /> : status === "failed" ? <Icon name="close" /> : <span className="spinner" />}</div><div className="job__main"><div className="job__title"><b>{title}</b><span>{status === "running" ? `${progress}%` : status}</span></div><span>{detail}</span><div className="progress"><i style={{ width: `${progress}%` }} /></div></div><IconButton icon="more" label="Job options" /></div>;
}

function EmptyState({ icon = "archive", title, text, action }: { icon?: IconName; title: string; text: string; action?: React.ReactNode }) {
  return <div className="empty-state"><div className="empty-state__icon"><Icon name={icon} size={24} /></div><h3>{title}</h3><p>{text}</p>{action}</div>;
}

function Overview({ go }: { go: (page: string) => void }) {
  return <div className="screen">
    <PageTitle eyebrow="Tuesday, 18 March" title="Good morning, Mira" description="Your research workspace is up to date. Three papers are ready for review." actions={<Button variant="primary" icon="plus" onClick={() => go("upload")}>Add papers</Button>} />
    <div className="metric-grid">
      <div className="metric"><span>Library</span><strong>147</strong><small>papers across 4 projects</small></div>
      <div className="metric"><span>Needs review</span><strong>12</strong><small>extracted claims</small></div>
      <div className="metric"><span>Reading list</span><strong>8</strong><small>3 added this week</small></div>
      <div className="metric metric--accent"><span>Local index</span><strong>100%</strong><small><i /> healthy · updated 8m ago</small></div>
    </div>
    <div className="dashboard-grid">
      <section className="panel panel--span2"><div className="section-head"><div><h2>Continue your work</h2><p>Recently active projects</p></div><Button variant="ghost" onClick={() => go("projects")}>View all <Icon name="arrow" size={14} /></Button></div>
        <div className="project-row" onClick={() => go("project")} role="button" tabIndex={0}><div className="project-mark">RA</div><div><b>Reliable retrieval evaluation</b><span>42 papers · 6 threads · edited 18 min ago</span></div><div className="project-progress"><span>Literature review</span><div className="progress"><i style={{ width: "72%" }} /></div></div><Icon name="chevron" /></div>
        <div className="project-row"><div className="project-mark project-mark--blue">LC</div><div><b>Long-context model behavior</b><span>31 papers · 3 threads · edited yesterday</span></div><div className="project-progress"><span>Evidence mapping</span><div className="progress"><i style={{ width: "44%" }} /></div></div><Icon name="chevron" /></div>
        <div className="project-row"><div className="project-mark project-mark--sand">TH</div><div><b>Thesis methods chapter</b><span>18 papers · 9 notes · edited 4 days ago</span></div><div className="project-progress"><span>Drafting</span><div className="progress"><i style={{ width: "29%" }} /></div></div><Icon name="chevron" /></div>
      </section>
      <section className="panel"><div className="section-head"><div><h2>Processing</h2><p>Runs locally on this device</p></div></div>
        <ProgressJob title="RAG evaluation batch" detail="Extracting setup fields · 3 of 5" progress={64} />
        <ProgressJob title="Dense retrieval survey" detail="Indexed 18 passages" progress={100} status="done" />
        <Button variant="ghost" onClick={() => go("upload")}>Open processing queue <Icon name="arrow" size={14} /></Button>
      </section>
      <section className="panel panel--span2"><div className="section-head"><div><h2>Decision log alerts</h2><p>New evidence related to recorded decisions</p></div><Pill tone="amber">2 need review</Pill></div>
        <div className="alert-row"><span className="alert-dot">!</span><div><b>New evidence may challenge your reranking decision</b><p>“Lost in the Middle” reports position sensitivity under the same retrieval depth used in your setup.</p><span>Linked decision: Use top-10 retrieved passages · 2 sources</span></div><Button>Review evidence</Button></div>
        <div className="alert-row"><span className="alert-dot alert-dot--info">i</span><div><b>A supporting result was added</b><p>Self-RAG reports improved citation accuracy under adaptive retrieval.</p><span>Linked decision: Evaluate adaptive retrieval · 3 sources</span></div><Button>Open decision</Button></div>
      </section>
      <section className="panel"><div className="section-head"><div><h2>Reading list</h2><p>8 saved · 5 unread</p></div></div>{papers.slice(1, 4).map((p) => <div className="mini-paper" key={p.title}><span>{p.title}</span><small>{p.authors} · {p.year}</small></div>)}<Button variant="ghost">Open reading list <Icon name="arrow" size={14} /></Button></section>
    </div>
  </div>;
}

function Library({ go }: { go: (page: string) => void }) {
  const [grid, setGrid] = useState(false);
  return <div className="screen"><PageTitle title="Papers" description="147 papers indexed locally across your research projects." actions={<><Button icon="download">Export</Button><Button variant="primary" icon="upload" onClick={() => go("upload")}>Upload papers</Button></>} />
    <div className="toolbar"><div className="field field--search"><Icon name="search" size={16} /><input aria-label="Search papers" placeholder="Search title, author, venue…" /></div><button className="select-like">All projects <Icon name="chevron" size={14} /></button><button className="select-like">Any status <Icon name="chevron" size={14} /></button><button className="select-like">2020–2025 <Icon name="chevron" size={14} /></button><div className="view-toggle"><IconButton icon="list" label="List view" onClick={() => setGrid(false)} /><IconButton icon="grid" label="Grid view" onClick={() => setGrid(true)} /></div></div>
    <div className="bulk-bar"><label><input type="checkbox" /> Select all</label><span>147 papers</span><div><Button variant="ghost">Add to project</Button><Button variant="ghost">Tag</Button></div></div>
    <div className={grid ? "paper-grid" : "paper-list"}>{papers.map((p, i) => <article className="paper-card" key={p.title} onClick={() => go("viewer")}><div className="paper-card__select"><input type="checkbox" aria-label={`Select ${p.title}`} onClick={(e) => e.stopPropagation()} /></div><div className="paper-thumb"><span>{p.venue}</span><b>{p.title.split(" ").slice(0, 3).join(" ")}</b><small>{p.year}</small></div><div className="paper-card__content"><div className="paper-card__meta"><Pill tone={p.status === "Processing" ? "blue" : p.status === "To review" ? "amber" : "neutral"}>{p.status}</Pill><Pill>{p.tag}</Pill></div><h3>{p.title}</h3><p>{p.authors} · {p.venue} {p.year}</p><small>{p.pages} pages · {i % 2 ? "Long-context project" : "Reliable retrieval evaluation"}</small></div><IconButton icon="more" label="Paper actions" /></article>)}</div>
  </div>;
}

function UploadScreen({ go }: { go: (page: string) => void }) {
  const [uploaded, setUploaded] = useState(false);
  return <div className="screen screen--narrow"><PageTitle title="Add papers" description="PDFs stay on this device. ResearchMind extracts text and builds the index locally." />
    {!uploaded ? <div className="dropzone" onClick={() => setUploaded(true)} role="button" tabIndex={0}><div className="dropzone__icon"><Icon name="upload" size={28} /></div><h2>Drop PDFs here</h2><p>or choose files from your computer</p><Button variant="primary">Choose files</Button><small>PDF · up to 100 MB each · multiple files supported</small></div> :
    <div className="upload-queue"><div className="section-head"><div><h2>Processing 5 papers</h2><p>You can leave this page. Processing continues locally.</p></div><Pill tone="blue">3 running</Pill></div>
      <ProgressJob title="Benchmarking RAG Systems.pdf" detail="Extracting tables · page 14 of 22" progress={64} />
      <ProgressJob title="Self-RAG.pdf" detail="Building semantic index · 86 passages" progress={82} />
      <ProgressJob title="Lost in the Middle.pdf" detail="Waiting for extraction slot" progress={8} status="queued" />
      <ProgressJob title="RAG for Knowledge-Intensive NLP.pdf" detail="12 pages indexed · 34 fields extracted" progress={100} status="done" />
      <ProgressJob title="Dense Retrieval without Labels.pdf" detail="18 pages indexed · 29 fields extracted" progress={100} status="done" />
      <div className="queue-actions"><Button icon="plus">Add more</Button><Button onClick={() => go("library")}>Open library</Button><Button variant="primary" onClick={() => go("extraction")}>Review extracted fields</Button></div>
    </div>}
    <section className="privacy-note"><Icon name="wifi" /><div><b>Local processing</b><p>Files, extracted text, and embeddings remain on this machine. Online discovery is currently off.</p></div><Button variant="ghost" onClick={() => go("settings")}>Review privacy settings</Button></section>
  </div>;
}

function Viewer() {
  const [page, setPage] = useState(6);
  return <div className="viewer">
    <div className="viewer__bar"><div><Button variant="ghost" icon="arrow">Papers</Button><span className="divider" /><b>Retrieval-Augmented Generation…</b></div><div><Button>−</Button><span>110%</span><Button>+</Button><Button icon="download">Export</Button></div></div>
    <div className="viewer__body"><aside className="thumbnails">{[1,2,3,4,5,6,7].map(n => <button key={n} className={page === n ? "active" : ""} onClick={() => setPage(n)}><span className="tiny-page" />{n}</button>)}</aside>
      <main className="pdf-stage"><div className="pdf-page"><div className="pdf-kicker">ADVANCES IN NEURAL INFORMATION PROCESSING SYSTEMS 33</div><h2>Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks</h2><p className="pdf-authors">Patrick Lewis · Ethan Perez · Aleksandra Piktus · Fabio Petroni · Vladimir Karpukhin</p><div className="pdf-columns"><div><h3>3. Retrieval-Augmented Generation</h3><p>We explore RAG models which combine parametric and non-parametric memory for language generation. The retriever provides passages conditioned on the input sequence.</p><p className="highlight">RAG models combine a pre-trained parametric memory with a non-parametric memory accessed through a dense vector index.</p><p>The retrieved passages are treated as latent variables and marginalized over in sequence generation.</p></div><div><h3>3.1 Models</h3><p>We train the retriever and generator jointly without direct supervision on what document should be retrieved. In the RAG-Sequence model, the same document is used to predict each target token.</p><div className="pdf-figure"><span>Input query</span><span>Retriever</span><span>Generator</span></div><p>This formulation supports factual generation while retaining explicit access to provenance.</p></div></div><small className="page-number">{page}</small></div></main>
      <aside className="inspector"><div className="tabs"><button className="active">Evidence</button><button>Fields</button><button>Checklist</button></div><div className="inspector__content"><Pill tone="teal">Selected highlight</Pill><h3>Evidence details</h3><EvidenceCard compact highlighted /><div className="field-pair"><span>Linked field</span><b>Retrieval architecture</b></div><div className="field-pair"><span>Extraction confidence</span><b>Both passes agree</b></div><Button variant="primary">Add to notes</Button><HowComputed /></div></aside>
    </div>
  </div>;
}

function SearchScreen({ go }: { go: (page: string) => void }) {
  const [semantic, setSemantic] = useState(true);
  return <div className="screen"><PageTitle title="Search your evidence" description="Search exact terms or meaning across 147 locally indexed papers." />
    <div className="search-hero"><div className="searchbox"><Icon name="search" /><input defaultValue="How does retrieval depth affect citation faithfulness?" aria-label="Search query" /><Button variant="primary">Search</Button></div><div className="search-options"><div className="segmented"><button className={!semantic ? "active" : ""} onClick={() => setSemantic(false)}>Keyword</button><button className={semantic ? "active" : ""} onClick={() => setSemantic(true)}>Semantic</button></div><label><input type="checkbox" defaultChecked /> Search within current project</label><span>⌘ Enter to search</span></div></div>
    <div className="results-layout"><main><div className="results-head"><div><b>24 passages found</b><span>Ranked by semantic relevance</span></div><button className="select-like">Most relevant <Icon name="chevron" size={14} /></button></div>
      <EvidenceCard onOpen={() => go("viewer")} /><EvidenceCard compact onOpen={() => go("viewer")} /><article className="evidence-card"><div className="evidence-card__top"><Pill tone="blue">p. 14</Pill><span>Liu et al. · 2024</span></div><blockquote>“Performance is often highest when relevant information occurs at the beginning or end of the input context, and significantly degrades in the middle.”</blockquote><div className="evidence-card__source"><span>Lost in the Middle: How Language Models Use Long Contexts</span><Button variant="ghost" onClick={() => go("viewer")}>Open in viewer <Icon name="arrow" size={14} /></Button></div></article>
    </main><aside className="filter-panel"><h3>Refine results</h3><label>Project<select><option>Reliable retrieval evaluation</option></select></label><label>Published<select><option>Any year</option></select></label><fieldset><legend>Tags</legend>{["Foundational","Methodology","Benchmark","Recent"].map(t => <label key={t}><input type="checkbox" /> {t}</label>)}</fieldset><HowComputed label="How results are ranked" /></aside></div>
  </div>;
}

function Projects({ go }: { go: (page: string) => void }) {
  return <div className="screen"><PageTitle title="Projects" description="Organize papers, threads, notes, and decisions around a research question." actions={<Button variant="primary" icon="plus">New project</Button>} />
    <div className="project-grid">{[
      ["Reliable retrieval evaluation","When and why does retrieval improve citation faithfulness?","42","6","RA"],
      ["Long-context model behavior","Position effects, context limits, and evaluation design.","31","3","LC"],
      ["Thesis methods chapter","Evidence and citations for the methodology chapter.","18","9","TH"],
      ["Evaluation benchmark notes","Dataset design and metric reliability across RAG benchmarks.","56","4","EB"],
    ].map((p,i) => <article className="project-card" key={p[0]} onClick={() => go("project")}><div className={`project-mark p${i}`}>{p[4]}</div><IconButton icon="more" label="Project options" /><h2>{p[0]}</h2><p>{p[1]}</p><div className="project-card__stats"><span><b>{p[2]}</b> papers</span><span><b>{p[3]}</b> threads</span></div><div className="project-card__foot"><span>{i ? "Edited yesterday" : "Edited 18 min ago"}</span><div className="avatar-stack"><i>M</i><i>JL</i></div></div></article>)}</div>
  </div>;
}

function ProjectDetail({ go }: { go: (page: string) => void }) {
  return <div className="screen"><PageTitle eyebrow="Project" title="Reliable retrieval evaluation" description="When and why does retrieval improve citation faithfulness?" actions={<><Button icon="settings">Project settings</Button><Button variant="primary" icon="plus">Add evidence</Button></>} />
    <div className="tabbar"><button className="active">Overview</button><button>Papers <span>42</span></button><button>Threads <span>6</span></button><button>Notes <span>12</span></button><button>Decisions <span>4</span></button></div>
    <div className="dashboard-grid"><section className="panel panel--span2"><div className="section-head"><div><h2>Research question</h2><p>Last refined 3 days ago</p></div><Button>Edit</Button></div><div className="research-question">Under which retrieval settings do generated answers remain faithful to cited passages, and how should faithfulness be evaluated across domains?</div><div className="chip-row"><Pill tone="teal">retrieval depth</Pill><Pill tone="teal">citation faithfulness</Pill><Pill tone="teal">evaluation</Pill><Pill>+2</Pill></div></section>
      <section className="panel"><div className="section-head"><div><h2>Project health</h2><p>Evidence coverage</p></div></div><div className="donut"><div><strong>72%</strong><span>reviewed</span></div></div><ul className="legend"><li><i className="teal" />30 reviewed</li><li><i className="amber" />8 need review</li><li><i />4 processing</li></ul></section>
      <section className="panel panel--span2"><div className="section-head"><div><h2>Recent evidence</h2><p>Saved from searches and threads</p></div><Button variant="ghost" onClick={() => go("search")}>Search project <Icon name="arrow" size={14} /></Button></div><EvidenceCard compact onOpen={() => go("viewer")} /></section>
      <section className="panel"><div className="section-head"><div><h2>Open questions</h2><p>Prompts for your next reading session</p></div></div><ol className="question-list"><li>Does retrieval depth interact with passage position?</li><li>Which faithfulness metrics correlate with human judgment?</li><li>Are benchmark results stable across domains?</li></ol><Button variant="ghost" onClick={() => go("threads")}>Start a thread <Icon name="arrow" size={14} /></Button></section>
    </div>
  </div>;
}

function Threads({ go }: { go: (page: string) => void }) {
  return <div className="screen"><PageTitle title="Threads" description="Questions, cited answers, and your notes—kept together as a research trail." actions={<Button variant="primary" icon="plus" onClick={() => go("thread")}>New thread</Button>} />
    <div className="thread-layout"><aside className="thread-filters"><b>Views</b><button className="active">All threads <span>18</span></button><button>Starred <span>4</span></button><button>Needs follow-up <span>3</span></button><b>Projects</b><button>Reliable retrieval <span>6</span></button><button>Long-context behavior <span>3</span></button><button>Thesis methods <span>9</span></button></aside>
      <main className="thread-list"><div className="toolbar"><div className="field field--search"><Icon name="search" size={16} /><input placeholder="Search threads…" aria-label="Search threads" /></div><button className="select-like">Recently updated <Icon name="chevron" size={14} /></button></div>
      {[
        ["Does retrieval depth improve citation faithfulness?","Synthesized from 7 papers · 12 evidence passages","Reliable retrieval evaluation","12 min ago"],
        ["Compare RAG-Sequence and RAG-Token assumptions","Synthesized from 3 papers · 8 evidence passages","Reliable retrieval evaluation","Yesterday"],
        ["What degrades long-context retrieval performance?","Insufficient evidence · 2 related passages","Long-context model behavior","2 days ago"],
        ["Human evaluation protocols for citation accuracy","Synthesized from 9 papers · 16 evidence passages","Thesis methods chapter","5 days ago"],
      ].map((t,i) => <article className="thread-row" key={t[0]} onClick={() => go("thread")}><div className="thread-row__icon"><Icon name="thread" /></div><div><h3>{t[0]}</h3><p>{t[1]}</p><span>{t[2]}</span></div>{i === 2 && <Pill tone="amber">Follow up</Pill>}<time>{t[3]}</time><Icon name="chevron" /></article>)}</main></div>
  </div>;
}

function ThreadDetail({ go }: { go: (page: string) => void }) {
  const [unsupported, setUnsupported] = useState(false);
  return <div className="thread-detail"><div className="thread-top"><div><Button variant="ghost" icon="arrow" onClick={() => go("threads")}>Threads</Button><span className="divider" /><b>Retrieval depth and citation faithfulness</b></div><div><label className="switch-label">Reading mode <span className="switch"><input type="checkbox" /><i /></span></label><IconButton icon="more" label="Thread options" /></div></div>
    <div className="conversation"><div className="user-prompt"><span>MM</span><div><small>You · today, 10:38</small><p>{unsupported ? "Does adaptive retrieval eliminate hallucinations in clinical decision support?" : "Across my library, what evidence connects retrieval depth with citation faithfulness?"}</p></div></div>
      {!unsupported ? <div className="answer"><div className="answer__head"><span className="rm-mark">R</span><div><b>ResearchMind</b><small>Answered from 7 papers · 12 passages</small></div><Disclaimer /></div><div className="answer__body"><p>The evidence in your library suggests that increasing retrieval depth can help only when the added passages remain relevant. Beyond that point, more context may dilute attention and reduce citation precision.</p><ol><li><b>Moderate retrieval depth improved coverage</b> in two benchmark settings, particularly for multi-hop questions. <button className="citation">1</button><button className="citation">2</button></li><li><b>Position and relevance appear to mediate the effect.</b> Relevant passages placed in the middle of long contexts were used less reliably. <button className="citation">3</button></li></ol><EvidenceCard compact onOpen={() => go("viewer")} /><HowComputed /></div></div> :
      <div className="insufficient"><div className="empty-state__icon"><Icon name="search" size={24} /></div><Pill tone="amber">Insufficient evidence</Pill><h2>Your library cannot support this answer yet</h2><p>I found two passages about adaptive retrieval, but neither studies clinical decision support or shows that hallucinations are eliminated.</p><div className="insufficient__actions"><Button variant="primary">Find possibly relevant references</Button><Button>Save as an open question</Button></div><div className="boundary"><b>What was searched</b><span>147 local papers · semantic and keyword retrieval · 0 direct matches</span></div><Disclaimer /><HowComputed /></div>}
      <div className="composer"><textarea aria-label="Ask your papers" placeholder="Ask a follow-up question…" /><div><span><Icon name="archive" size={15} /> Current project · 42 papers</span><Button variant="primary" icon="arrow" onClick={() => setUnsupported(!unsupported)}>Ask</Button></div></div>
      <button className="demo-link" onClick={() => setUnsupported(!unsupported)}>{unsupported ? "Return to cited answer" : "Try unsupported-question state"}</button>
    </div>
  </div>;
}

function Agreement({ status }: { status: "agree" | "verify" | "confirmed" | "edited" }) {
  const content = { agree: "Both passes agree", verify: "Verify manually", confirmed: "Confirmed by you", edited: "Edited by you" }[status];
  return <Pill tone={status === "verify" ? "amber" : status === "agree" ? "blue" : "teal"}>{status !== "verify" && <Icon name="check" size={11} />}{content}</Pill>;
}

function SearchReceipt({ expanded = false }: { expanded?: boolean }) {
  return <section className="receipt">
    <div className="receipt__head"><div><span className="receipt-mark"><Icon name="search" size={17} /></span><div><h3>Search receipt</h3><p>Permanent record · 18 Mar 2025, 10:42</p></div></div><Pill tone="blue">Online discovery</Pill></div>
    <div className="receipt__grid"><div><span>Queries run</span><b>6</b></div><div><span>Sources searched</span><b>3</b></div><div><span>Results screened</span><b>184</b></div><div><span>Candidate papers</span><b>12</b></div></div>
    <div className="receipt__section"><b>Queries run</b><code>“retrieval depth” AND “citation faithfulness”</code><code>RAG context precision evaluation benchmark</code>{expanded && <><code>adaptive retrieval factual consistency</code><code>passage position citation accuracy</code></>}</div>
    <div className="receipt__columns"><div><b>Sources searched</b><span><Icon name="check" size={13} /> OpenAlex</span><span><Icon name="check" size={13} /> Semantic Scholar</span><span><Icon name="check" size={13} /> Your local library</span></div><div><b>Not searched</b><span>Scopus</span><span>Web of Science</span><span>ProQuest Dissertations</span></div></div>
    <div className="receipt__notice"><Icon name="help" size={15} /><b>Absence of results is not evidence of novelty.</b></div>
    <HowComputed label="Search method and filters" />
  </section>;
}

function AnalysisTitle({ title, description, actions }: { title: string; description: string; actions?: React.ReactNode }) {
  return <><PageTitle title={title} description={description} actions={actions} /><div className="analysis-meta"><Disclaimer /><span>Last analyzed today, 10:42 · qwen2.5:14b · local</span></div></>;
}

const evaluationRows = [
  ["When does retrieval improve factuality?", "Supported", "3/3", "0.91", "Pass"],
  ["Does adaptive retrieval eliminate hallucination?", "Refused", "—", "0.88", "Pass"],
  ["What depth performs best on HotpotQA?", "Supported", "2/3", "0.74", "Review"],
  ["Is RAG always more accurate than long context?", "Refused", "—", "0.82", "Pass"],
];

function Evaluation() {
  return <div className="screen"><AnalysisTitle title="Evaluation" description="Track retrieval quality, citation grounding, and appropriate refusal across your test set." actions={<><Button>Configure suite</Button><Button variant="primary">Run evaluation</Button></>} />
    <div className="eval-metrics">{[["Recall@10","0.86","+0.04"],["MRR","0.79","+0.02"],["Citation faithfulness","92%","+3.1%"],["Refusal accuracy","88%","−1.0%"]].map((m,i)=><div className="metric" key={m[0]}><span>{m[0]}</span><strong>{m[1]}</strong><small className={i===3?"review-text":""}>{m[2]} vs prior</small></div>)}</div>
    <div className="analysis-grid"><section className="panel analysis-chart"><div className="section-head"><div><h2>Performance history</h2><p>Six evaluation runs · 48 questions</p></div><button className="select-like">All metrics <Icon name="chevron" size={14}/></button></div><svg viewBox="0 0 700 210" role="img" aria-label="Evaluation metrics trending upward across six runs"><g className="chart-grid"><path d="M45 20V180M45 180H675M45 140H675M45 100H675M45 60H675M45 20H675" /></g><path className="chart-line chart-line--teal" d="M50 145 C120 136 145 120 190 125 S280 100 320 105 S405 84 450 88 S535 63 580 69 S635 49 670 52" /><path className="chart-line chart-line--blue" d="M50 164 C100 157 150 145 190 150 S270 129 320 134 S405 108 450 112 S530 96 580 99 S640 84 670 86" />{[50,190,320,450,580,670].map((x,i)=><circle key={x} className="chart-dot" cx={x} cy={[145,125,105,88,69,52][i]} r="4"/>)}</svg><div className="chart-legend"><span><i className="teal"/>Citation faithfulness</span><span><i className="blue"/>Recall@10</span></div></section>
      <section className="panel"><div className="section-head"><div><h2>Extraction accuracy</h2><p>Human-confirmed field set · n=286</p></div></div><div className="accuracy-ring"><strong>94.1%</strong><span>exact match</span></div>{[["Method",98],["Dataset",96],["Metric value",91],["Conditions",87]].map(x=><div className="accuracy-row" key={x[0]}><span>{x[0]}</span><div className="progress"><i style={{width:`${x[1]}%`}}/></div><b>{x[1]}%</b></div>)}</section></div>
    <section className="table-panel"><div className="section-head"><div><h2>Per-question results</h2><p>4 of 48 questions shown</p></div><Button icon="download">Export results</Button></div><div className="data-scroll"><table className="data-table"><thead><tr><th>Question</th><th>Behavior</th><th>Citations valid</th><th>Faithfulness</th><th>Status</th><th /></tr></thead><tbody>{evaluationRows.map(r=><tr key={r[0]}><td><b>{r[0]}</b></td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td><Pill tone={r[4]==="Review"?"amber":"teal"}>{r[4]}</Pill></td><td><IconButton icon="chevron" label="Open question"/></td></tr>)}</tbody></table></div><HowComputed /></section>
  </div>;
}

function FindReferences({ go }: { go: (page:string)=>void }) {
  const [saved,setSaved]=useState<number[]>([]);
  const candidates = [
    ["Evaluating Correctness and Faithfulness of Instruction-Following Models","Min et al. · 2023","“Citation precision declines when retrieved context contains topically related but unsupported distractors.”",["methodology","benchmark"]],
    ["Benchmarking Large Language Models in Retrieval-Augmented Generation","Chen et al. · 2024","“Increasing the number of retrieved documents improves answer coverage but introduces a measurable faithfulness trade-off.”",["recent","benchmark"]],
    ["Making Retrieval-Augmented Language Models Robust to Irrelevant Context","Yoran et al. · 2024","“Robustness to irrelevant passages depends on both retrieval rank and the model's context filtering behavior.”",["methodology","recent"]],
  ];
  return <div className="screen"><AnalysisTitle title="Find references" description="Turn a claim into editable searches, then inspect why each candidate may be relevant." actions={<Button onClick={()=>go("receipt")}>View search receipt</Button>} />
    <section className="claim-builder"><label>Claim or paragraph to investigate<textarea defaultValue="Increasing retrieval depth improves answer coverage, but may reduce citation faithfulness when irrelevant passages enter the context." /></label><div className="builder-foot"><span>Queries and external sources are shown before anything is searched.</span><Button variant="primary" icon="search">Find possibly relevant work</Button></div></section>
    <div className="query-strip"><div><b>Generated queries</b><span>Edit these before searching again</span></div>{["retrieval depth citation faithfulness","irrelevant passages RAG answer coverage","context precision retrieval evaluation"].map(q=><label key={q}><input defaultValue={q}/><IconButton icon="close" label="Remove query"/></label>)}<IconButton icon="plus" label="Add query"/></div>
    <div className="candidate-layout"><main><div className="results-head"><div><b>12 candidate references</b><span>Ordered by possible relevance, not quality</span></div><Disclaimer /></div>{candidates.map((c,i)=><article className="candidate-card" key={c[0]}><div className="candidate-card__rank">{String(i+1).padStart(2,"0")}</div><div><h2>{c[0]}</h2><p>{c[1]} · {i===0?"ACL":"arXiv"}</p><div className="why"><span>Why possibly relevant</span><blockquote>{c[2]}</blockquote><small>Abstract · exact sentence</small></div><div className="chip-row">{(c[3] as string[]).map(t=><Pill key={t}>{t}</Pill>)}</div></div><div className="candidate-card__actions"><Button variant={saved.includes(i)?"secondary":"primary"} icon={saved.includes(i)?"check":"plus"} onClick={()=>setSaved([...saved,i])}>{saved.includes(i)?"Saved":"Save to reading list"}</Button><Button>Open abstract</Button></div></article>)}</main><aside><SearchReceipt /></aside></div>
    {saved.length>0&&<div className="flow-toast"><Icon name="check"/><span>{saved.length} paper saved to your reading list</span><Button variant="ghost" onClick={()=>go("reading")}>Open reading list</Button></div>}
  </div>;
}

function ReadingList({ go }: { go:(page:string)=>void }) {
  const groups=[["To read",["Benchmarking Large Language Models in Retrieval-Augmented Generation","Making Retrieval-Augmented Language Models Robust to Irrelevant Context"]],["Reading",["Lost in the Middle: How Language Models Use Long Contexts"]],["Read",["Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks"]]];
  return <div className="screen"><PageTitle title="Reading list" description="A focused queue for papers you want to evaluate yourself." actions={<Button onClick={()=>go("references")} icon="plus">Find references</Button>} /><div className="reading-board">{groups.map((g,gi)=><section className="reading-column" key={g[0]}><div className="section-head"><div><h2>{g[0]}</h2><p>{g[1].length} papers</p></div><IconButton icon="more" label="Column options"/></div>{(g[1] as string[]).map((title,i)=><article className="reading-card" key={title}><div><Pill>{gi===0?"Recent":gi===1?"Benchmark":"Foundational"}</Pill><IconButton icon="more" label="Paper options"/></div><h3>{title}</h3><p>{gi===2?"Lewis et al. · 2020":"Chen et al. · 2024"}</p><label>My note<textarea defaultValue={i===0&&gi===0?"Check their definition of faithfulness against our evaluation protocol.":gi===1?"Position effect may explain contradictory depth results.":""} placeholder="Add a note…"/></label><div><Button variant="ghost">{gi===0?"Start reading":gi===1?"Continue · p. 14":"Open notes"}</Button><span>{gi===1?"46% read":gi===2?"Completed 12 Mar":"Added today"}</span></div></article>)}</section>)}</div></div>;
}

function SearchReceiptView() {
  return <div className="screen screen--narrow"><PageTitle eyebrow="Reference discovery" title="Search receipt" description="A reproducible record of what was searched, where, when, and what was not covered." actions={<Button icon="download">Export receipt</Button>} /><SearchReceipt expanded /><section className="panel receipt-results"><div className="section-head"><div><h2>Result funnel</h2><p>Counts at each screening stage</p></div></div>{[["Results returned","184"],["Duplicates removed","31"],["Titles screened","153"],["Abstracts inspected","38"],["Candidates saved","12"]].map(x=><div key={x[0]}><span>{x[0]}</span><b>{x[1]}</b></div>)}</section></div>;
}

const extractionFields = [
  ["Method","RAG-Sequence","“The RAG-Sequence model uses the same retrieved document to generate the complete sequence.”","p. 5","agree"],
  ["Dataset","Natural Questions","“We evaluate on open-domain QA tasks: Natural Questions, TriviaQA, WebQuestions…”","p. 7","confirmed"],
  ["Retrieval depth","Top 5 passages","Pass A: top 5 passages","p. 6","verify"],
  ["Metric value","44.5 EM","“RAG-Sequence obtains 44.5 exact match on the Natural Questions test set.”","p. 8","edited"],
  ["Hardware","Not reported","No supporting passage located in methods or appendix.","—","verify"],
  ["Seeds","3 random seeds","Pass A: 3 seeds · Pass B: 5 seeds","p. 17","verify"],
  ["Code link","github.com/huggingface/transformers","“Code and model checkpoints are available…”","p. 12","agree"],
];

function ExtractionReview({ go }: { go:(page:string)=>void }) {
  const [verifyOnly,setVerifyOnly]=useState(false);
  const [confirmed,setConfirmed]=useState<string[]>([]);
  const rows=verifyOnly?extractionFields.filter(r=>r[4]==="verify"):extractionFields;
  return <div className="screen screen--wide"><AnalysisTitle title="Extraction review" description="Confirm every extracted setup field against the quoted source before using it in comparisons." actions={<><Button onClick={()=>go("contradictions")}>View contradictions</Button><Button variant="primary">Confirm reviewed fields</Button></>} />
    <section className="paper-context"><div className="paper-thumb"><span>NEURIPS</span><b>Retrieval-Augmented Generation</b><small>2020</small></div><div><h2>Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks</h2><p>Lewis et al. · NeurIPS 2020 · 12 pages</p></div><div className="review-progress"><span>Review progress <b>{confirmed.length+4} / 13</b></span><div className="progress"><i style={{width:`${((confirmed.length+4)/13)*100}%`}}/></div></div></section>
    <div className="table-toolbar"><div className="segmented"><button className={!verifyOnly?"active":""} onClick={()=>setVerifyOnly(false)}>All fields <span>13</span></button><button className={verifyOnly?"active":""} onClick={()=>setVerifyOnly(true)}>Verify manually <span>3</span></button></div><div><button className="select-like">All field groups <Icon name="chevron" size={14}/></button><Button icon="download">Export</Button></div></div>
    <section className="table-panel extraction-panel"><div className="data-scroll"><table className="data-table extraction-table"><thead><tr><th>Field</th><th>Extracted value</th><th>Source evidence</th><th>Agreement</th><th>Review</th></tr></thead><tbody>{rows.map(r=><tr key={r[0]} className={r[4]==="verify"?"row-review":""}><td><b>{r[0]}</b></td><td>{r[0]==="Seeds"?<div className="candidate-values"><span><small>PASS A</small>3 random seeds</span><span><small>PASS B</small>5 random seeds</span></div>:<b className={r[1]==="Not reported"?"muted":""}>{r[1]}</b>}</td><td><div className="cell-quote"><q>{r[2]}</q><button onClick={()=>go("viewer")}>{r[3]} <Icon name="arrow" size={12}/></button></div></td><td><Agreement status={(confirmed.includes(r[0])?"confirmed":r[4]) as "agree"|"verify"|"confirmed"|"edited"}/></td><td><div className="row-actions"><IconButton icon="check" label="Confirm" onClick={()=>setConfirmed([...confirmed,r[0]])}/><IconButton icon="file" label="Edit"/><IconButton icon="close" label="Reject"/></div></td></tr>)}</tbody></table></div><HowComputed /></section>
  </div>;
}

function PaperDiff({ go }: { go:(page:string)=>void }) {
  const rows=[["Method","RAG-Sequence","Self-reflective retrieval","Adaptive retrieval"],["Dataset","Natural Questions","PopQA","Natural Questions"],["Retriever","DPR","Contriever-MS MARCO","E5-large"],["Retrieval depth","Top 5","Adaptive: 0–5","Top 10"],["Generator","BART-large","Llama 2 7B","Llama 2 13B"],["Citation metric","Attribution precision","Citation correctness","AutoAIS"],["Score","74.2%","81.6%","78.9%"],["Seeds","3","Not reported","5"]];
  return <div className="screen screen--wide"><AnalysisTitle title="Paper diff" description="Compare reported setups cell by cell. Highlighting indicates difference, not superiority." actions={<><Button icon="plus">Add paper</Button><Button variant="primary" onClick={()=>go("prediction")}>Start think-first comparison</Button></>} />
    <div className="diff-pickers">{papers.slice(0,3).map((p,i)=><div key={p.title}><span className={`project-mark p${i}`}>{i+1}</span><div><small>PAPER {i+1}</small><b>{p.title}</b><span>{p.authors} · {p.year}</span></div><IconButton icon="close" label="Remove paper"/></div>)}</div>
    <section className="table-panel diff-panel"><div className="difference-key"><span><i/>Values differ</span><span><i className="missing"/>Not reported</span><label><input type="checkbox" defaultChecked/> Highlight differences</label></div><div className="data-scroll"><table className="data-table diff-table"><thead><tr><th>Setup field</th><th>Lewis et al. · 2020</th><th>Asai et al. · 2024</th><th>Chen et al. · 2024</th></tr></thead><tbody>{rows.map((r,ri)=><tr key={r[0]}><td><b>{r[0]}</b></td>{r.slice(1).map((v,i)=><td key={i} className={ri>0&&new Set(r.slice(1)).size>1?(v==="Not reported"?"diff-missing":"diff-cell"):""}><div className="diff-value"><span>{v}</span>{ri!==0&&<button className="quote-trigger" title={`“${ri===3?"We retrieve the top-k passages for each question.":"Reported in the experimental setup."}” · p. ${6+i}`}><Icon name="book" size={13}/> p. {6+i}</button>}</div></td>)}</tr>)}</tbody></table></div><HowComputed /></section>
  </div>;
}

function Contradictions({ go }: { go:(page:string)=>void }) {
  const [tolerance,setTolerance]=useState(5);
  return <div className="screen screen--wide"><AnalysisTitle title="Contradiction view" description="Candidate result conflicts where method, dataset, and metric align but reported values differ." actions={<Button onClick={()=>go("diff")}>Open paper diff</Button>} />
    <section className="tolerance-bar"><div><b>Numeric matching tolerance</b><span>Flag values differing by more than the selected relative amount.</span></div><input type="range" min="1" max="20" value={tolerance} onChange={e=>setTolerance(Number(e.target.value))}/><strong>{tolerance}%</strong><Pill tone="amber">3 candidate conflicts</Pill></section>
    {[["Natural Questions · Exact Match","44.5","41.2","Lewis et al. · 2020","Chen et al. · 2024"],["HotpotQA · Citation correctness","78.9%","71.4%","Asai et al. · 2024","Liu et al. · 2024"]].map((c,i)=><article className="contradiction-card" key={c[0]}><div className="contradiction-head"><div><Pill tone="amber">Candidate conflict {String(i+1).padStart(2,"0")}</Pill><h2>{c[0]}</h2><p>Same stated task and primary metric · values differ by {i? "9.5%":"7.4%"}</p></div><Disclaimer /></div><div className="value-compare"><div><span>{c[3]}</span><strong>{c[1]}</strong><blockquote>“Our RAG-Sequence model obtains {c[1]} on the test set using five retrieved passages.”</blockquote><button onClick={()=>go("viewer")}>p. 8 · Open evidence <Icon name="arrow" size={13}/></button></div><div className="versus">vs</div><div><span>{c[4]}</span><strong>{c[2]}</strong><blockquote>“Under the replicated setup, exact match reaches {c[2]} averaged across three runs.”</blockquote><button onClick={()=>go("viewer")}>p. 11 · Open evidence <Icon name="arrow" size={13}/></button></div></div><div className="setup-differences"><b>Reported setup differences</b><div><span>Retriever checkpoint</span><b>DPR-NQ</b><b>DPR-Multi</b></div><div><span>Evaluation script</span><b>Official NQ</b><b>Normalized aliases</b></div><div><span>Random seeds</span><b>Not reported</b><b>3 seeds</b></div></div><div className="reason-grid"><div><span>Possible reasons (not conclusions)</span><ul><li>Different retriever checkpoint or corpus snapshot</li><li>Answer normalization may not be equivalent</li></ul></div><div><span>Candidate experiment (suggestion)</span><p>Run both checkpoints against one frozen corpus and one evaluation script, reporting variance across five seeds.</p><Button>Create experiment note</Button></div></div><HowComputed /></article>)}
  </div>;
}

function NumericConsistency({ go }: { go:(page:string)=>void }) {
  return <div className="screen"><AnalysisTitle title="Numeric consistency" description="Potential mismatches between values reported in prose, tables, and appendices." actions={<Button icon="download">Export report</Button>} /><section className="paper-context"><div className="paper-thumb"><span>ICLR</span><b>Self-RAG</b><small>2024</small></div><div><h2>Self-RAG: Learning to Retrieve, Generate, and Critique</h2><p>3 candidate mismatches · 28 numeric mentions checked</p></div><Agreement status="verify"/></section>{[["Citation accuracy","81.6%","79.8%","The main text and Table 3 report different values for the same evaluation split."],["Training examples","150k","145,619","Rounded total in methods differs from the appendix count."]].map((x,i)=><article className="mismatch-card" key={x[0]}><div className="mismatch-head"><div><Pill tone="amber">Verify manually</Pill><h2>{x[0]}</h2><p>{x[3]}</p></div><Button onClick={()=>go("viewer")}>Open paper</Button></div><div className="quote-compare"><div><span>Main text · p. {8+i}</span><strong>{x[1]}</strong><blockquote>“The model achieves {x[1]} citation accuracy on the held-out test split.”</blockquote></div><div><span>Table {3+i} · p. {10+i}</span><strong>{x[2]}</strong><blockquote>“Self-RAG (7B), test citation accuracy: {x[2]}.”</blockquote></div></div><div className="row-actions"><Button icon="check">Mark checked</Button><Button icon="file">Add note</Button></div></article>)}</div>;
}

function Reproducibility({ go }: { go:(page:string)=>void }) {
  const items=[["Dataset and split","reported","Natural Questions · standard train/dev/test","p. 7"],["Primary metric","reported","Exact match with alias normalization","p. 8"],["Model checkpoint","reported","BART-large · DPR-NQ","p. 5"],["Hyperparameters","partial","Learning rate and batch size given; scheduler absent","p. 16"],["Random seeds","missing","No seed count located","—"],["Hardware","missing","No accelerator or runtime details located","—"],["Code and artifacts","reported","Repository and checkpoints linked","p. 12"]];
  return <div className="screen"><AnalysisTitle title="Reproducibility X-ray" description="A source-linked view of what the paper reports and what could not be located." actions={<Button icon="download">Export checklist</Button>} /><div className="xray-summary"><div><strong>4</strong><span>Reported</span></div><div><strong>1</strong><span>Partially reported</span></div><div><strong>2</strong><span>Not located</span></div><p>“Missing” means the analysis did not locate supporting text. Verify the paper and supplements manually.</p></div><section className="table-panel"><div className="data-scroll"><table className="data-table"><thead><tr><th>Reproducibility item</th><th>Status</th><th>Reported detail</th><th>Evidence</th></tr></thead><tbody>{items.map(r=><tr key={r[0]}><td><b>{r[0]}</b></td><td><Pill tone={r[1]==="reported"?"teal":"amber"}>{r[1]==="missing"?"Not located":r[1]}</Pill></td><td>{r[2]}</td><td>{r[3]!=="—"?<Button variant="ghost" onClick={()=>go("viewer")}>{r[3]} <Icon name="arrow" size={12}/></Button>:<span className="muted">No passage</span>}</td></tr>)}</tbody></table></div><HowComputed /></section></div>;
}

function Overclaim() {
  return <div className="screen screen--wide"><AnalysisTitle title="Overclaim meter" description="Review strong wording against the evidence you have linked. No score or verdict is assigned." actions={<Button variant="primary">Review next highlight</Button>} /><div className="editor-split"><section className="draft-editor"><div className="editor-bar"><b>Discussion draft</b><span>3 passages to review</span></div><div contentEditable suppressContentEditableWarning className="editor-content"><h2>4.2 Retrieval depth and reliability</h2><p>Our findings indicate that retrieval can improve evidence coverage in knowledge-intensive tasks.</p><p><mark>Increasing retrieval depth always produces more faithful answers.</mark> This pattern appears across all model sizes and domains.</p><p>However, passage position and distractor relevance may influence whether retrieved evidence is used.</p><p><mark>Adaptive retrieval eliminates hallucination by allowing the model to critique its own output.</mark></p></div></section><aside className="claim-review"><Pill tone="amber">Strong wording to review</Pill><h2>“always produces more faithful answers”</h2><div className="wording-compare"><div><span>Draft wording</span><b>always produces</b></div><Icon name="arrow"/><div><span>Evidence supports</span><b>can improve under some settings</b></div></div><EvidenceCard compact /><div className="review-prompt"><b>Questions for you</b><ul><li>Does your evidence cover every model size and domain claimed?</li><li>Could retrieval relevance qualify this statement?</li></ul></div><div className="row-actions"><Button>Keep wording</Button><Button variant="primary">Edit in draft</Button></div><HowComputed /></aside></div></div>;
}

function CitationAudit({ go }: { go:(page:string)=>void }) {
  const audits=[["Retrieval-augmented models improve factuality by grounding generations in external documents [12].","“RAG models outperform parametric-only baselines on open-domain question answering and generate more factual, specific language.”","Directly related"],["Longer contexts consistently improve citation accuracy across datasets [27].","“Performance is often highest when relevant information occurs at the beginning or end, and degrades in the middle.”","Needs your review"]];
  return <div className="screen"><AnalysisTitle title="Library citation audit" description="Compare each citing sentence with the most relevant passage in the cited paper." actions={<Button icon="upload">Import draft</Button>} />{audits.map((a,i)=><article className="audit-card" key={a[0]}><div className="audit-head"><span>Citation [{i?27:12}] · Discussion, paragraph {i+3}</span><Agreement status={i?"verify":"agree"}/></div><div className="audit-compare"><div><small>CITING SENTENCE</small><blockquote>{a[0]}</blockquote></div><div><small>CITED PAPER · MOST RELEVANT PASSAGE</small><blockquote>{a[1]}</blockquote><span>Lewis et al. · 2020 · p. {i?14:2}</span></div></div><div className="audit-foot"><Pill tone={i?"amber":"blue"}>{a[2]}</Pill><Button variant="ghost" onClick={()=>go("viewer")}>Open cited passage <Icon name="arrow" size={13}/></Button></div></article>)}</div>;
}

function PriorWork({ go }: { go:(page:string)=>void }) {
  return <div className="screen"><AnalysisTitle title="Prior-work audit" description="Map a rough idea against possibly related work before deciding how to position it." actions={<Button variant="primary" onClick={()=>go("references")}>Find more references</Button>} /><div className="legal-notice"><Icon name="help"/><div><b>Not a legal or patentability opinion. No novelty score.</b><p>This is a literature-search aid. Coverage depends on the sources and queries shown in the receipt.</p></div></div><section className="claim-builder"><label>Your rough idea<textarea defaultValue="A retrieval controller that predicts when additional passages will reduce citation faithfulness, then stops retrieval before irrelevant evidence enters context." /></label><div className="builder-foot"><span>Last audited today · 184 results screened</span><Button variant="primary">Run audit again</Button></div></section><h2 className="section-title">Closest papers found</h2>{papers.slice(1,4).map((p,i)=><article className="overlap-card" key={p.title}><span className="candidate-card__rank">{String(i+1).padStart(2,"0")}</span><div><h3>{p.title}</h3><p>{p.authors} · {p.year}</p><div className="overlap-grid"><span><small>PROBLEM</small>{i?"Retrieval robustness":"Context position effects"}</span><span><small>METHOD</small>{i?"Adaptive retrieval":"Controlled evaluation"}</span><span><small>DATASET</small>{i?"PopQA · PubHealth":"Natural Questions"}</span></div></div><Button>Compare overlap</Button></article>)}<SearchReceipt /></div>;
}

function GapMap({ go }: { go:(page:string)=>void }) {
  const clusters=[["Evaluation beyond answer accuracy","8 papers · 14 supporting statements","Current benchmarks under-specify citation placement, source quality, and uncertainty calibration."],["Robustness to retrieval noise","6 papers · 11 supporting statements","Future work calls for evaluation under stale, contradictory, and partially relevant evidence."],["Domain-specific refusal behavior","4 papers · 7 supporting statements","Few studies connect retrieval confidence with appropriate refusal in high-stakes domains."]];
  return <div className="screen"><AnalysisTitle title="Candidate gap map" description="Clusters of limitations and future-work statements for you to inspect—not claims of novelty." actions={<Button>Adjust clustering</Button>} /><div className="gap-notice"><Pill tone="blue">Candidate gaps for you to evaluate</Pill><p>Clusters reflect language in your library. A dense cluster may indicate active work rather than an open gap.</p></div><div className="gap-grid">{clusters.map((c,i)=><article className="gap-card" key={c[0]}><div className={`gap-orb orb-${i}`}><span>{8-i*2}</span><small>papers</small></div><div><span>CLUSTER {String(i+1).padStart(2,"0")}</span><h2>{c[0]}</h2><p>{c[2]}</p><div className="chip-row"><Pill>limitations</Pill><Pill>future work</Pill>{i===1&&<Pill>methodology</Pill>}</div></div><div className="gap-evidence"><b>Supporting statements</b><blockquote>“Future evaluations should consider whether generated citations remain attributable under increasingly noisy retrieval conditions.”</blockquote><span>Chen et al. · 2024 · p. 18</span><blockquote>“Robust refusal under insufficient or conflicting evidence remains underexplored.”</blockquote><span>Asai et al. · 2024 · p. 12</span><Button variant="ghost" onClick={()=>go("viewer")}>Review {c[1]} <Icon name="arrow" size={13}/></Button></div></article>)}</div></div>;
}

function PredictionGate({ go }: { go:(page:string)=>void }) {
  const [revealed,setRevealed]=useState(false);
  return <div className="screen screen--narrow">{!revealed?<><PageTitle eyebrow="Think first" title="What do you expect to find?" description="Write your prediction before revealing the extracted comparison. Your note stays linked to this analysis." /><div className="prediction-stepper"><span className="active">1 <b>Predict</b></span><i/><span>2 <b>Compare</b></span><i/><span>3 <b>Reflect</b></span></div><section className="prediction-card"><div className="compare-context"><div><Pill>3 papers</Pill><h2>Retrieval setup comparison</h2><p>Retrieval depth, citation metric, and reported performance</p></div></div><label>Your prediction or summary<textarea placeholder="Before seeing the extracted fields, I expect…" defaultValue="I expect adaptive retrieval to use fewer passages on simple questions and show higher citation accuracy, but the comparison may be confounded by different datasets and generators." /></label><div className="prediction-prompts"><b>Optional prompts</b><span>Which result do you expect to be strongest?</span><span>What setup difference may matter most?</span></div><div className="builder-foot"><label><input type="checkbox" defaultChecked/> Use Think-first by default for this project</label><Button variant="primary" onClick={()=>setRevealed(true)}>Save prediction and reveal comparison</Button></div></section></>:<><PageTitle eyebrow="Think first · comparison revealed" title="Compare your prediction with the evidence" description="These prompts organize your review; they do not grade your prediction." actions={<Button onClick={()=>go("diff")}>Open full paper diff</Button>} /><div className="prediction-stepper done"><span>1 <b>Predicted</b></span><i/><span>2 <b>Compare</b></span><i/><span className="active">3 <b>Reflect</b></span></div><div className="prediction-results">{[["Matched","Adaptive retrieval used between zero and five passages, while fixed systems used five and ten.","teal"],["Possibly missed","The adaptive system was evaluated on PopQA, not Natural Questions; scores are not directly comparable.","amber"],["Check this reading","Citation correctness and AutoAIS are differently defined metrics.","blue"]].map((x,i)=><article key={x[0]}><Pill tone={x[2] as "teal"|"amber"|"blue"}>{x[0]}</Pill><p>{x[1]}</p><EvidenceCard compact={true} highlighted={i===1}/></article>)}</div><div className="reflection-box"><label>Your reflection<textarea placeholder="What changed in your understanding?" /></label><Button variant="primary">Save reflection</Button></div></>}</div>;
}

function DecisionLog({ go }: { go:(page:string)=>void }) {
  return <div className="screen"><PageTitle title="Decision log" description="Record research choices with rationale and evidence so they can be revisited when new work arrives." actions={<Button variant="primary" icon="plus">Record decision</Button>} /><div className="decision-filter"><div className="segmented"><button className="active">All decisions</button><button>Needs review <span>2</span></button></div><button className="select-like">Reliable retrieval evaluation <Icon name="chevron" size={14}/></button></div>{[["Use top-10 passages for the baseline","Chosen to maximize evidence coverage while preserving a fixed comparison point.","Conflict to review"],["Report citation precision and recall separately","A combined score obscures whether a system over-cites or misses evidence.","Active"],["Freeze the Wikipedia corpus snapshot","Prevents index drift between model comparison runs.","Active"]].map((d,i)=><article className={`decision-card ${i===0?"decision-card--alert":""}`} key={d[0]}><div className="decision-timeline"><i/><span>{i?"08 Mar":"14 Mar"}</span></div><div className="decision-main"><div className="decision-head"><div><Pill tone={i===0?"amber":"teal"}>{d[2]}</Pill><h2>{d[0]}</h2></div><IconButton icon="more" label="Decision actions"/></div><p><b>Rationale</b>{d[1]}</p><div className="decision-evidence"><span><Icon name="archive" size={14}/> {i+2} linked evidence passages</span><Button variant="ghost" onClick={()=>go("viewer")}>Review evidence <Icon name="arrow" size={13}/></Button></div>{i===0&&<div className="conflict-alert"><span>!</span><div><b>New paper may conflict with this decision</b><p>Liu et al. report lower evidence use when relevant passages appear mid-context at similar depth.</p></div><Button>Compare evidence</Button></div>}</div></article>)}</div>;
}

function Provenance() {
  const [marked,setMarked]=useState(true);
  return <div className="screen screen--wide"><PageTitle title="Provenance log" description="Mark passages you used AI assistance on and export your own writing record." actions={<Button icon="download">Export log</Button>} /><div className="provenance-notice"><Icon name="help"/><b>This tool records your own marking. It does not detect AI text.</b></div><div className="provenance-layout"><section className="notes-editor"><div className="editor-bar"><div><b>Methods notes</b><span>Saved locally just now</span></div><Button icon="more">Document</Button></div><div contentEditable suppressContentEditableWarning className="editor-content"><h2>Retrieval evaluation protocol</h2><p>We evaluate citation precision separately from answer correctness because a correct answer may still cite an unsupported source.</p><p className={marked?"ai-marked":""}>The protocol uses passage-level entailment as a screening measure, followed by manual review of ambiguous cases.</p><p>All disagreements are retained in the extraction log and resolved before aggregate comparison.</p></div><div className="selection-toolbar"><Button variant={marked?"primary":"secondary"} onClick={()=>setMarked(!marked)}><Icon name="file" size={14}/>{marked?"Marked AI-assisted":"Mark AI-assisted"}</Button><span>Selected passage · 18 words</span></div></section><aside className="provenance-side"><h2>Document summary</h2><div className="provenance-stats"><div><strong>418</strong><span>total words</span></div><div><strong>18</strong><span>marked words</span></div></div><p>Marks are descriptive metadata only. No percentage is used as an authorship claim.</p><h3>Recent activity</h3>{[["AI-assisted mark added","Paragraph 2 · 18 words","Today, 11:04"],["Passage edited","Paragraph 1 · 7 words","Today, 10:58"],["Document created","Methods notes","17 Mar, 16:22"]].map(x=><div className="log-event" key={x[0]}><i/><div><b>{x[0]}</b><span>{x[1]}</span></div><time>{x[2]}</time></div>)}</aside></div><section className="table-panel provenance-table"><div className="section-head"><div><h2>Provenance events</h2><p>Append-only activity for this project</p></div><button className="select-like">All event types <Icon name="chevron" size={14}/></button></div><div className="data-scroll"><table className="data-table"><thead><tr><th>Timestamp</th><th>Document</th><th>Event</th><th>Passage</th><th>Recorded by</th></tr></thead><tbody><tr><td>Today, 11:04</td><td>Methods notes</td><td><Pill tone="blue">AI-assisted mark</Pill></td><td>“The protocol uses passage-level…”</td><td>Mira Malik</td></tr><tr><td>Today, 10:58</td><td>Methods notes</td><td>Manual edit</td><td>“We evaluate citation precision…”</td><td>Mira Malik</td></tr></tbody></table></div></section></div>;
}

function Settings() {
  const [online, setOnline] = useState(false);
  return <div className="screen"><PageTitle title="Settings" description="Manage local models, privacy, analysis behavior, and your data." />
    <div className="settings-layout"><aside>{["AI & models","Privacy","Analysis","Appearance","Data & export"].map((x,i) => <button className={i === 0 ? "active" : ""} key={x}>{x}</button>)}</aside><main>
      <section className="settings-section"><div className="settings-heading"><div><h2>Local AI connection</h2><p>ResearchMind uses Ollama to run models on this machine.</p></div><Pill tone="teal"><i className="status-dot" /> Connected</Pill></div><label>Ollama URL<div className="input-action"><input defaultValue="http://localhost:11434" /><Button>Test connection</Button></div><small>Connected · Ollama 0.6.2 · checked just now</small></label><div className="two-col"><label>Answer model<select defaultValue="qwen"><option value="qwen">qwen2.5:14b</option><option>llama3.2:8b</option></select></label><label>Embedding model<select><option>nomic-embed-text</option></select></label></div></section>
      <section className="settings-section"><div className="settings-heading"><div><h2>Online discovery</h2><p>Search external scholarly indexes for papers not in your library.</p></div><span className="switch"><input type="checkbox" checked={online} onChange={() => setOnline(!online)} /><i /></span></div><div className={`online-explainer ${online ? "active" : ""}`}><Icon name={online ? "wifi" : "archive"} /><div><b>{online ? "Online discovery is active" : "Local mode only"}</b><p>{online ? "Your search query and filters may be sent to OpenAlex and Semantic Scholar. Paper files and notes never leave this device." : "Searches use only your local library. No queries, papers, notes, or embeddings leave this device."}</p></div></div></section>
      <section className="settings-section"><div className="settings-heading"><div><h2>Analysis defaults</h2><p>Choose how ResearchMind supports your reading process.</p></div></div><div className="setting-row"><div><b>Think-first by default</b><p>Ask for your prediction before revealing extracted comparisons.</p></div><span className="switch"><input type="checkbox" defaultChecked /><i /></span></div><label>Numeric comparison tolerance<div className="range-row"><input type="range" min="0" max="20" defaultValue="5" /><b>5%</b></div><small>Values within this range are treated as approximately equivalent, not identical.</small></label></section>
      <section className="settings-section"><div className="settings-heading"><div><h2>Your data</h2><p>Export a portable archive or permanently remove local data.</p></div></div><div className="setting-row"><div><b>Export all data</b><p>Papers, annotations, projects, threads, and provenance logs.</p></div><Button icon="download">Create export</Button></div><div className="setting-row"><div><b>Delete all data</b><p>This permanently removes ResearchMind data from this device.</p></div><Button variant="danger">Delete data…</Button></div></section>
    </main></div>
  </div>;
}

function Login({ onEnter }: { onEnter: () => void }) {
  const [step, setStep] = useState(0);
  return <div className="login"><div className="login__brand"><div className="brand-mark">R</div><span>ResearchMind</span></div><div className="login__visual"><div className="quote-visual"><span>Evidence 03 · p. 14</span><blockquote>“The strongest research tools make uncertainty visible—and keep the source within reach.”</blockquote><div><i /><small>Your library stays on this machine.</small></div></div><p>A local-first research companion that shows the evidence and leaves the thinking to you.</p></div><main className="login__card">{step === 0 ? <><div className="step-count">STEP 1 OF 2</div><h1>Create your local workspace</h1><p>Set a password for this device. No account or internet connection is required.</p><label>Your name<input defaultValue="Mira Malik" /></label><label>Local password<input type="password" defaultValue="researchmind" /></label><label>Confirm password<input type="password" defaultValue="researchmind" /></label><Button variant="primary" onClick={() => setStep(1)}>Continue <Icon name="arrow" size={15} /></Button><small className="login-note"><Icon name="archive" size={14} /> Your password is stored securely on this device and cannot be recovered remotely.</small></> : <><div className="step-count">STEP 2 OF 2</div><h1>Connect local AI</h1><p>ResearchMind uses Ollama for private, on-device analysis.</p><div className="connection-ok"><Icon name="check" /><div><b>Ollama is ready</b><span>http://localhost:11434 · version 0.6.2</span></div></div><label>Answer model<select defaultValue="qwen"><option value="qwen">qwen2.5:14b · Recommended</option><option>llama3.2:8b</option></select></label><label>Embedding model<select><option>nomic-embed-text</option></select></label><Button variant="primary" onClick={onEnter}>Open ResearchMind <Icon name="arrow" size={15} /></Button><Button variant="ghost" onClick={() => setStep(0)}>Back</Button></>}</main></div>;
}

const navGroups = [
  { label: "Workspace", items: [["overview","home","Overview"],["library","book","Papers"],["search","search","Search"],["upload","upload","Add papers"]] },
  { label: "Research", items: [["projects","folder","Projects"],["threads","thread","Threads"]] },
  { label: "Evaluate", items: [["evaluation","grid","Evaluation"],["extraction","list","Extraction review"],["diff","file","Paper diff"],["contradictions","archive","Contradictions"]] },
  { label: "Discover", items: [["references","search","Find references"],["reading","book","Reading list"],["receipt","file","Search receipts"],["prior","folder","Prior-work audit"],["gaps","grid","Gap map"]] },
  { label: "Integrity", items: [["numeric","archive","Numeric consistency"],["reproducibility","check","Reproducibility"],["overclaim","file","Overclaim meter"],["audit","book","Citation audit"]] },
  { label: "Think first", items: [["prediction","help","Prediction gate"],["decisions","clock","Decision log"],["provenance","file","Provenance log"]] },
];

function AppShell() {
  const [page, setPage] = useState("overview");
  const [dark, setDark] = useState(false);
  const [rightPanel, setRightPanel] = useState<"evidence" | "copilot" | null>(null);
  const [online] = useState(false);
  const screen = useMemo(() => {
    if (page === "overview") return <Overview go={setPage} />;
    if (page === "library") return <Library go={setPage} />;
    if (page === "upload") return <UploadScreen go={setPage} />;
    if (page === "viewer") return <Viewer />;
    if (page === "search") return <SearchScreen go={setPage} />;
    if (page === "projects") return <Projects go={setPage} />;
    if (page === "project") return <ProjectDetail go={setPage} />;
    if (page === "threads") return <Threads go={setPage} />;
    if (page === "thread") return <ThreadDetail go={setPage} />;
    if (page === "evaluation") return <Evaluation />;
    if (page === "references") return <FindReferences go={setPage} />;
    if (page === "reading") return <ReadingList go={setPage} />;
    if (page === "receipt") return <SearchReceiptView />;
    if (page === "extraction") return <ExtractionReview go={setPage} />;
    if (page === "diff") return <PaperDiff go={setPage} />;
    if (page === "contradictions") return <Contradictions go={setPage} />;
    if (page === "numeric") return <NumericConsistency go={setPage} />;
    if (page === "reproducibility") return <Reproducibility go={setPage} />;
    if (page === "overclaim") return <Overclaim />;
    if (page === "audit") return <CitationAudit go={setPage} />;
    if (page === "prior") return <PriorWork go={setPage} />;
    if (page === "gaps") return <GapMap go={setPage} />;
    if (page === "prediction") return <PredictionGate go={setPage} />;
    if (page === "decisions") return <DecisionLog go={setPage} />;
    if (page === "provenance") return <Provenance />;
    if (page === "settings") return <Settings />;
    return <Overview go={setPage} />;
  }, [page]);
  return <div className={`app ${dark ? "dark" : ""}`}>
    <aside className="sidebar"><button className="brand" onClick={() => setPage("overview")}><span className="brand-mark">R</span><b>ResearchMind</b></button><button className="project-switcher"><span className="project-mini">RA</span><span><small>Current project</small><b>Reliable retrieval</b></span><Icon name="chevron" size={14} /></button>
      <nav>{navGroups.map(g => <div className="nav-group" key={g.label}><span>{g.label}</span>{g.items.map(item => <button key={item[0]} className={page === item[0] ? "active" : ""} onClick={() => setPage(item[0])}><Icon name={item[1] as IconName} /><b>{item[2]}</b>{item[0] === "upload" && <Pill tone="blue">3</Pill>}</button>)}</div>)}</nav>
      <div className="sidebar__bottom"><div className="local-card"><div><i /><b>Local mode</b></div><span>Nothing leaves this device</span></div><button onClick={() => setPage("settings")} className={page === "settings" ? "active" : ""}><Icon name="settings" /><b>Settings</b></button><button><Icon name="help" /><b>Help & shortcuts</b></button></div>
    </aside>
    <div className="app-main"><header className="topbar"><button className="global-search" onClick={() => setPage("search")}><Icon name="search" size={16} /><span>Search papers, evidence, threads…</span><kbd>⌘ K</kbd></button><div className="topbar__actions"><span className={`mode-indicator ${online ? "online" : ""}`}><i />{online ? "Online discovery active" : "Local mode"}</span><IconButton icon={dark ? "sun" : "moon"} label="Toggle theme" onClick={() => setDark(!dark)} /><IconButton icon="thread" label="Open copilot" onClick={() => setRightPanel(rightPanel === "copilot" ? null : "copilot")} /><IconButton icon="archive" label="Toggle evidence panel" onClick={() => setRightPanel(rightPanel === "evidence" ? null : "evidence")} /><button className="avatar">MM</button></div></header><div className="content">{screen}</div></div>
    {rightPanel === "evidence" && <aside className="evidence-drawer"><div className="drawer-head"><div><span>Evidence panel</span><b>3 items in view</b></div><IconButton icon="close" label="Close panel" onClick={() => setRightPanel(null)} /></div><div className="drawer-body"><p>Evidence connected to your current context appears here.</p><EvidenceCard compact onOpen={() => { setPage("viewer"); setRightPanel(null); }} /><EvidenceCard compact onOpen={() => { setPage("viewer"); setRightPanel(null); }} /><HowComputed /></div></aside>}
    {rightPanel === "copilot" && <aside className="evidence-drawer copilot-drawer"><div className="drawer-head"><div><span>Research copilot</span><b>Reliable retrieval evaluation</b></div><IconButton icon="close" label="Close copilot" onClick={() => setRightPanel(null)} /></div><div className="drawer-body"><div className="copilot-scope"><Icon name="archive" size={15} /><span>Answers use 42 papers in this project</span></div><div className="copilot-question">What setup differences could explain the conflicting citation-faithfulness results?</div><div className="copilot-answer"><div className="answer__head"><span className="rm-mark">R</span><div><b>Evidence-led answer</b><small>3 excerpts · 2 papers</small></div></div><p>The studies vary in retrieval depth and where supporting passages appear in context. These are possible explanations to verify, not conclusions.</p><ol><li>Lewis et al. retrieve five passages per query. <button className="citation">1</button></li><li>Liu et al. show sensitivity to passage position. <button className="citation">2</button></li></ol><Disclaimer /><HowComputed /></div><div className="composer"><textarea aria-label="Ask research copilot" placeholder="Ask your project evidence…" /><div><span>Enter to ask · Shift Enter for line break</span><Button variant="primary" icon="arrow">Ask</Button></div></div></div></aside>}
  </div>;
}

export default function App() {
  const [setup, setSetup] = useState(false);
  return setup ? <Login onEnter={() => setSetup(false)} /> : <><AppShell /><button className="setup-preview" onClick={() => setSetup(true)}>Preview first-run setup</button></>;
}
